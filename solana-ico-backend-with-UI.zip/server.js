const express = require("express")
const cors = require("cors")
const dotenv = require("dotenv")
const morgan = require("morgan")
const helmet = require("helmet")
const rateLimit = require("express-rate-limit")

// Load environment variables
dotenv.config()

// Import routes
const icoRoutes = require("./routes/ico.routes")
const stakingRoutes = require("./routes/staking.routes")
const userRoutes = require("./routes/user.routes")

// Initialize express app
const app = express()

// Set up middleware
app.use(helmet()) // Security headers
app.use(cors()) // Enable CORS
app.use(express.json()) // Parse JSON bodies
app.use(morgan("dev")) // Logging

// Rate limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
})
app.use("/api", apiLimiter)

// Routes
app.use("/api/ico", icoRoutes)
app.use("/api/staking", stakingRoutes)
app.use("/api/users", userRoutes)

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(500).json({
    success: false,
    error: process.env.NODE_ENV === "production" ? "Server error" : err.message,
  })
})

// Start server
const PORT = process.env.PORT || 5000
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})

module.exports = app

