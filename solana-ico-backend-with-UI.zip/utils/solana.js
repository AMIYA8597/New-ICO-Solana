const { Connection, Keypair } = require("@solana/web3.js")
const bs58 = require("bs58")

/**
 * Create a Solana connection with the configured endpoint
 */
exports.createConnectionConfig = () => {
  const endpoint = process.env.SOLANA_RPC_ENDPOINT || "https://api.devnet.solana.com"
  return new Connection(endpoint, "confirmed")
}

/**
 * Get a keypair from environment variable
 */
exports.getKeypairFromEnv = () => {
  const privateKey = process.env.ADMIN_PRIVATE_KEY
  if (!privateKey) {
    throw new Error("ADMIN_PRIVATE_KEY environment variable is not set")
  }

  // Convert base58 private key to Uint8Array
  const decodedKey = bs58.decode(privateKey)
  return Keypair.fromSecretKey(decodedKey)
}

/**
 * Format lamports to SOL
 */
exports.formatSol = (lamports) => {
  return (lamports / 1e9).toFixed(9)
}

/**
 * Format unix timestamp to date string
 */
exports.formatUnixTimestamp = (timestamp) => {
  return new Date(timestamp * 1000).toLocaleString()
}

