"use client"

import StakingAdmin from "../src/pages/StakingAdmin"

export default function SyntheticV0PageForDeployment() {
  return <StakingAdmin />
}