const express = require("express")
const router = express.Router()
const stakingController = require("../controllers/staking.controller")

// Staking routes
router.get("/details", stakingController.getStakingDetails)
router.post("/initialize", stakingController.initializeStaking)
router.post("/stake", stakingController.stakeTokens)
router.post("/unstake", stakingController.unstakeTokens)
router.post("/update-params", stakingController.updateStakingParams)
router.post("/create-coupon", stakingController.createCoupon)
router.get("/user-stakes", stakingController.getUserStakes)

module.exports = router

