const express = require("express")
const router = express.Router()
const userController = require("../controllers/user.controller")

// User routes
router.get("/token-balance/:wallet", userController.getTokenBalance)
router.get("/purchases/:wallet", userController.getUserPurchases)
router.get("/stakes/:wallet", userController.getUserStakes)

module.exports = router

