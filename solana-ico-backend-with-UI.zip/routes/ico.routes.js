const express = require("express")
const router = express.Router()
const icoController = require("../controllers/ico.controller")

// ICO routes
router.get("/details", icoController.getIcoDetails)
router.post("/initialize", icoController.initializeIco)
router.post("/buy-tokens", icoController.buyTokens)
router.post("/distribute-tokens", icoController.distributeTokens)
router.post("/update-round", icoController.updateRound)
router.post("/end-ico", icoController.endIco)
router.get("/analytics", icoController.getAnalytics)
router.post("/add-seed-investor", icoController.addSeedInvestor)
router.post("/remove-seed-investor", icoController.removeSeedInvestor)

module.exports = router

