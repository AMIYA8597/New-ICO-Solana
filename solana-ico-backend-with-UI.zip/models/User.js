const mongoose = require("mongoose")

const UserSchema = new mongoose.Schema({
  wallet: {
    type: String,
    required: true,
    unique: true,
  },
  isSeedInvestor: {
    type: Boolean,
    default: false,
  },
  totalPurchased: {
    type: String,
    default: "0",
  },
  totalStaked: {
    type: String,
    default: "0",
  },
  spinCount: {
    type: Number,
    default: 0,
  },
  spinEligibilityTier: {
    type: Number,
    default: 0,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  lastActive: {
    type: Date,
    default: Date.now,
  },
})

module.exports = mongoose.model("User", UserSchema)

