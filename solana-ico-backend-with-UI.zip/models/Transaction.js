const mongoose = require("mongoose")

const TransactionSchema = new mongoose.Schema({
  transactionId: {
    type: String,
    required: true,
    unique: true,
  },
  type: {
    type: String,
    enum: ["buy", "distribute", "stake", "unstake", "initialize", "update", "end"],
    required: true,
  },
  wallet: {
    type: String,
    required: true,
  },
  amount: {
    type: String,
  },
  status: {
    type: String,
    enum: ["pending", "confirmed", "failed"],
    default: "pending",
  },
  timestamp: {
    type: Date,
    default: Date.now,
  },
  metadata: {
    type: mongoose.Schema.Types.Mixed,
  },
})

module.exports = mongoose.model("Transaction", TransactionSchema)

