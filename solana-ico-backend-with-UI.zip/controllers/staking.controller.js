const { Connection, PublicKey, Keypair } = require("@solana/web3.js")
const { Program, AnchorProvider, BN, web3 } = require("@project-serum/anchor")
const { TOKEN_PROGRAM_ID } = require("@solana/spl-token")
const stakingIdl = require("../utils/idl/staking_program.json")
const { getKeypairFromEnv, createConnectionConfig } = require("../utils/solana")

// Initialize connection and program
const connection = createConnectionConfig()
const programId = new PublicKey(process.env.STAKING_PROGRAM_ID)

// Get staking details
exports.getStakingDetails = async (req, res) => {
  try {
    const provider = AnchorProvider.env()
    const program = new Program(stakingIdl, programId, provider)

    const [stakingAccount] = await PublicKey.findProgramAddress([Buffer.from("staking_account")], program.programId)

    const stakingData = await program.account.stakingAccount.fetch(stakingAccount)

    res.json({
      success: true,
      data: {
        admin: stakingData.admin.toString(),
        lockupPeriod: stakingData.lockupPeriod.toString(),
        totalStaked: stakingData.totalStaked.toString(),
        endTimestamp: stakingData.endTimestamp.toString(),
        tokenMint: stakingData.tokenMint.toString(),
        lowTierFee: stakingData.lowTierFee,
        midTierFee: stakingData.midTierFee,
        highTierFee: stakingData.highTierFee,
        activeCoupons: stakingData.activeCoupons.map((coupon) => ({
          code: coupon.code,
          bonusType: Object.keys(coupon.bonusType)[0],
          bonusValue: coupon.bonusValue,
          startTimestamp: coupon.startTimestamp.toString(),
          endTimestamp: coupon.endTimestamp.toString(),
          minStakeAmount: coupon.minStakeAmount.toString(),
          maxUses: coupon.maxUses.toString(),
          currentUses: coupon.currentUses.toString(),
          couponCategory: Object.keys(coupon.couponCategory)[0],
          isActive: coupon.isActive,
        })),
      },
    })
  } catch (error) {
    console.error("Error fetching staking details:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

// Initialize staking
exports.initializeStaking = async (req, res) => {
  try {
    const { lockupPeriod, lowTierFee, midTierFee, highTierFee } = req.body

    const provider = AnchorProvider.env()
    const program = new Program(stakingIdl, programId, provider)

    // Get admin keypair from environment
    const adminKeypair = getKeypairFromEnv()

    // Find staking account PDA
    const [stakingAccount] = await PublicKey.findProgramAddress([Buffer.from("staking_account")], program.programId)

    // Get token mint from environment
    const tokenMint = new PublicKey(process.env.TOKEN_MINT_ADDRESS)

    // Convert parameters
    const bnLockupPeriod = new BN(lockupPeriod)

    // Initialize staking
    const tx = await program.methods
      .initialize(bnLockupPeriod, lowTierFee, midTierFee, highTierFee)
      .accounts({
        stakingAccount,
        admin: adminKeypair.publicKey,
        tokenMint,
        systemProgram: web3.SystemProgram.programId,
      })
      .signers([adminKeypair])
      .rpc()

    res.json({
      success: true,
      data: {
        transactionId: tx,
        stakingAccount: stakingAccount.toString(),
      },
    })
  } catch (error) {
    console.error("Error initializing staking:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

// Stake tokens
exports.stakeTokens = async (req, res) => {
  try {
    const { amount, stakerWallet, couponCode } = req.body

    const provider = AnchorProvider.env()
    const program = new Program(stakingIdl, programId, provider)

    // Find staking account PDA
    const [stakingAccount] = await PublicKey.findProgramAddress([Buffer.from("staking_account")], program.programId)

    // Create staker public key
    const staker = new PublicKey(stakerWallet)

    // Create a new stake record account
    const stakeRecord = Keypair.generate()

    // Find staker info PDA
    const [stakerInfo] = await PublicKey.findProgramAddress(
      [Buffer.from("staker_info"), stakingAccount.toBuffer(), staker.toBuffer()],
      program.programId,
    )

    // Get staking data to get token mint
    const stakingData = await program.account.stakingAccount.fetch(stakingAccount)
    const tokenMint = stakingData.tokenMint

    // Find staker token account
    const stakerTokenAccounts = await connection.getTokenAccountsByOwner(staker, {
      mint: tokenMint,
    })

    if (stakerTokenAccounts.value.length === 0) {
      throw new Error("Staker has no token account for this mint")
    }

    const stakerTokenAccount = stakerTokenAccounts.value[0].pubkey

    // Find admin staking wallet
    const adminTokenAccounts = await connection.getTokenAccountsByOwner(stakingData.admin, {
      mint: tokenMint,
    })

    if (adminTokenAccounts.value.length === 0) {
      throw new Error("Admin has no token account for this mint")
    }

    const adminStakingWallet = adminTokenAccounts.value[0].pubkey

    // Convert amount to lamports
    const amountLamports = new BN(amount)

    // Stake tokens
    const tx = await program.methods
      .stakeTokens(amountLamports, couponCode ? couponCode : null)
      .accounts({
        stakingAccount,
        stakeRecord: stakeRecord.publicKey,
        stakerInfo,
        stakerTokenAccount,
        adminStakingWallet,
        staker,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: web3.SystemProgram.programId,
      })
      .signers([stakeRecord])
      .rpc()

    res.json({
      success: true,
      data: {
        transactionId: tx,
        stakeRecord: stakeRecord.publicKey.toString(),
      },
    })
  } catch (error) {
    console.error("Error staking tokens:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

// Unstake tokens
exports.unstakeTokens = async (req, res) => {
  try {
    const { amount, stakerWallet, stakeRecordAddress } = req.body

    const provider = AnchorProvider.env()
    const program = new Program(stakingIdl, programId, provider)

    // Find staking account PDA
    const [stakingAccount] = await PublicKey.findProgramAddress([Buffer.from("staking_account")], program.programId)

    // Create staker public key
    const staker = new PublicKey(stakerWallet)

    // Create stake record public key
    const stakeRecord = new PublicKey(stakeRecordAddress)

    // Find staker info PDA
    const [stakerInfo] = await PublicKey.findProgramAddress(
      [Buffer.from("staker_info"), stakingAccount.toBuffer(), staker.toBuffer()],
      program.programId,
    )

    // Get staking data to get token mint and admin
    const stakingData = await program.account.stakingAccount.fetch(stakingAccount)
    const tokenMint = stakingData.tokenMint
    const admin = stakingData.admin

    // Find staker token account
    const stakerTokenAccounts = await connection.getTokenAccountsByOwner(staker, {
      mint: tokenMint,
    })

    if (stakerTokenAccounts.value.length === 0) {
      throw new Error("Staker has no token account for this mint")
    }

    const stakerTokenAccount = stakerTokenAccounts.value[0].pubkey

    // Find admin staking wallet
    const adminTokenAccounts = await connection.getTokenAccountsByOwner(admin, {
      mint: tokenMint,
    })

    if (adminTokenAccounts.value.length === 0) {
      throw new Error("Admin has no token account for this mint")
    }

    const adminStakingWallet = adminTokenAccounts.value[0].pubkey

    // Convert amount to lamports
    const amountLamports = new BN(amount)

    // Unstake tokens
    const tx = await program.methods
      .unstakeCombined(amountLamports)
      .accounts({
        stakingAccount,
        stakeRecord,
        stakerInfo,
        stakerTokenAccount,
        adminStakingWallet,
        tokenMint,
        staker,
        owner: admin,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: web3.SystemProgram.programId,
      })
      .rpc()

    res.json({
      success: true,
      data: {
        transactionId: tx,
      },
    })
  } catch (error) {
    console.error("Error unstaking tokens:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

// Update staking parameters
exports.updateStakingParams = async (req, res) => {
  try {
    const { lockupPeriod, lowTierFee, midTierFee, highTierFee } = req.body

    const provider = AnchorProvider.env()
    const program = new Program(stakingIdl, programId, provider)

    // Get admin keypair from environment
    const adminKeypair = getKeypairFromEnv()

    // Find staking account PDA
    const [stakingAccount] = await PublicKey.findProgramAddress([Buffer.from("staking_account")], program.programId)

    // Convert parameters
    const bnLockupPeriod = new BN(lockupPeriod)

    // Update staking parameters
    const tx = await program.methods
      .update(bnLockupPeriod, lowTierFee, midTierFee, highTierFee)
      .accounts({
        stakingAccount,
        admin: adminKeypair.publicKey,
        systemProgram: web3.SystemProgram.programId,
      })
      .signers([adminKeypair])
      .rpc()

    res.json({
      success: true,
      data: {
        transactionId: tx,
      },
    })
  } catch (error) {
    console.error("Error updating staking parameters:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

// Create coupon
exports.createCoupon = async (req, res) => {
  try {
    const { code, bonusType, bonusValue, duration, minStakeAmount, maxUses, couponCategory } = req.body

    const provider = AnchorProvider.env()
    const program = new Program(stakingIdl, programId, provider)

    // Get admin keypair from environment
    const adminKeypair = getKeypairFromEnv()

    // Find staking account PDA
    const [stakingAccount] = await PublicKey.findProgramAddress([Buffer.from("staking_account")], program.programId)

    // Convert parameters
    const bnDuration = new BN(duration)
    const bnMinStakeAmount = new BN(minStakeAmount)
    const bnMaxUses = new BN(maxUses)

    // Convert bonus type
    let bonusTypeObj
    switch (bonusType) {
      case "Percentage":
        bonusTypeObj = { percentage: {} }
        break
      case "FixedAmount":
        bonusTypeObj = { fixedAmount: {} }
        break
      case "SpinBonus":
        bonusTypeObj = { spinBonus: {} }
        break
      default:
        throw new Error("Invalid bonus type")
    }

    // Convert coupon category
    let couponCategoryObj
    switch (couponCategory) {
      case "NewUser":
        couponCategoryObj = { newUser: {} }
        break
      case "Referral":
        couponCategoryObj = { referral: {} }
        break
      case "LoyaltyReward":
        couponCategoryObj = { loyaltyReward: {} }
        break
      case "SeasonalPromo":
        couponCategoryObj = { seasonalPromo: {} }
        break
      case "Exclusive":
        couponCategoryObj = { exclusive: {} }
        break
      default:
        throw new Error("Invalid coupon category")
    }

    // Create coupon
    const tx = await program.methods
      .createCoupon(code, bonusTypeObj, bonusValue, bnDuration, bnMinStakeAmount, bnMaxUses, couponCategoryObj)
      .accounts({
        stakingAccount,
        admin: adminKeypair.publicKey,
        systemProgram: web3.SystemProgram.programId,
      })
      .signers([adminKeypair])
      .rpc()

    res.json({
      success: true,
      data: {
        transactionId: tx,
        couponCode: code,
      },
    })
  } catch (error) {
    console.error("Error creating coupon:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

// Get user stakes
exports.getUserStakes = async (req, res) => {
  try {
    const { walletAddress } = req.params

    const provider = AnchorProvider.env()
    const program = new Program(stakingIdl, programId, provider)

    // Create wallet public key
    const wallet = new PublicKey(walletAddress)

    // Find staking account PDA
    const [stakingAccount] = await PublicKey.findProgramAddress([Buffer.from("staking_account")], program.programId)

    // Find staker info PDA
    const [stakerInfo] = await PublicKey.findProgramAddress(
      [Buffer.from("staker_info"), stakingAccount.toBuffer(), wallet.toBuffer()],
      program.programId,
    )

    // Try to fetch staker info
    let stakerInfoData
    try {
      stakerInfoData = await program.account.stakerInfo.fetch(stakerInfo)
    } catch (error) {
      // If staker info doesn't exist, return empty data
      return res.json({
        success: true,
        data: {
          totalStaked: "0",
          spinCount: 0,
          spinEligibilityTier: 0,
          stakeRecords: [],
        },
      })
    }

    // Get all stake records for this staker
    const stakeAccounts = await connection.getProgramAccounts(program.programId, {
      filters: [
        { dataSize: program.account.stakeRecord.size },
        { memcmp: { offset: 8, bytes: wallet.toBase58() } }, // owner field
      ],
    })

    // Process stake records
    const stakeRecords = await Promise.all(
      stakeAccounts.map(async (account) => {
        const stakeRecord = await program.account.stakeRecord.fetch(account.pubkey)
        return {
          pubkey: account.pubkey.toString(),
          owner: stakeRecord.owner.toString(),
          amount: stakeRecord.amount.toString(),
          stakeTimestamp: stakeRecord.stakeTimestamp.toString(),
          endTimestamp: stakeRecord.endTimestamp.toString(),
          tier: stakeRecord.tier,
          spinCount: stakeRecord.spinCount,
          spinEligibilityTier: stakeRecord.spinEligibilityTier,
          isInitialized: stakeRecord.isInitialized,
        }
      }),
    )

    res.json({
      success: true,
      data: {
        totalStaked: stakerInfoData.totalStaked.toString(),
        spinCount: stakerInfoData.spinCount,
        spinEligibilityTier: stakerInfoData.spinEligibilityTier,
        stakedAmount: stakerInfoData.stakedAmount.toString(),
        stakeTimestamp: stakerInfoData.stakeTimestamp.toString(),
        stakeRecords,
      },
    })
  } catch (error) {
    console.error("Error getting user stakes:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

