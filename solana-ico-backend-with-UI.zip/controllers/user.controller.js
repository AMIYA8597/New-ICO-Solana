const { Connection, PublicKey } = require("@solana/web3.js")
const { Program, AnchorProvider } = require("@project-serum/anchor")
const icoIdl = require("../utils/idl/ico_program.json")
const stakingIdl = require("../utils/idl/staking_program.json")
const { createConnectionConfig } = require("../utils/solana")

// Initialize connection
const connection = createConnectionConfig()
const icoProgram = new PublicKey(process.env.ICO_PROGRAM_ID)
const stakingProgram = new PublicKey(process.env.STAKING_PROGRAM_ID)

// Get token balance
exports.getTokenBalance = async (req, res) => {
  try {
    const { wallet } = req.params

    const provider = AnchorProvider.env()
    const program = new Program(icoIdl, icoProgram, provider)

    // Find ICO account PDA
    const [icoAccount] = await PublicKey.findProgramAddress([Buffer.from("ico")], program.programId)

    // Fetch ICO data to get token mint
    const icoData = await program.account.icoAccount.fetch(icoAccount)
    const tokenMint = icoData.tokenMint

    // Create wallet public key
    const walletPubkey = new PublicKey(wallet)

    // Find token accounts for this wallet and mint
    const tokenAccounts = await connection.getTokenAccountsByOwner(walletPubkey, {
      mint: tokenMint,
    })

    // Calculate total balance
    let totalBalance = 0
    for (const account of tokenAccounts.value) {
      const accountInfo = await connection.getTokenAccountBalance(account.pubkey)
      totalBalance += Number.parseInt(accountInfo.value.amount)
    }

    res.json({
      success: true,
      data: {
        wallet,
        tokenMint: tokenMint.toString(),
        balance: totalBalance.toString(),
      },
    })
  } catch (error) {
    console.error("Error getting token balance:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

// Get user purchases
exports.getUserPurchases = async (req, res) => {
  try {
    const { wallet } = req.params

    const provider = AnchorProvider.env()
    const program = new Program(icoIdl, icoProgram, provider)

    // Find ICO account PDA
    const [icoAccount] = await PublicKey.findProgramAddress([Buffer.from("ico")], program.programId)

    // Create wallet public key
    const walletPubkey = new PublicKey(wallet)

    // Get all purchase accounts for this wallet
    const purchaseAccounts = await connection.getProgramAccounts(program.programId, {
      filters: [
        { dataSize: program.account.purchaseAccount.size },
        { memcmp: { offset: 8, bytes: walletPubkey.toBase58() } }, // buyer field
      ],
    })

    // Process purchase data
    const purchases = await Promise.all(
      purchaseAccounts.map(async (account) => {
        const purchaseData = await program.account.purchaseAccount.fetch(account.pubkey)
        return {
          pubkey: account.pubkey.toString(),
          buyer: purchaseData.buyer.toString(),
          amount: purchaseData.amount.toString(),
          isDistributed: purchaseData.isDistributed,
          timestamp: purchaseData.timestamp.toString(),
          ico: purchaseData.ico.toString(),
          purchasePrice: purchaseData.purchasePrice.toString(),
          round: Object.keys(purchaseData.round)[0],
          counter: purchaseData.counter.toString(),
        }
      }),
    )

    res.json({
      success: true,
      data: {
        wallet,
        purchases,
      },
    })
  } catch (error) {
    console.error("Error getting user purchases:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

// Get user stakes
exports.getUserStakes = async (req, res) => {
  try {
    const { wallet } = req.params

    const provider = AnchorProvider.env()
    const program = new Program(stakingIdl, stakingProgram, provider)

    // Find staking account PDA
    const [stakingAccount] = await PublicKey.findProgramAddress([Buffer.from("staking_account")], program.programId)

    // Create wallet public key
    const walletPubkey = new PublicKey(wallet)

    // Find staker info PDA
    const [stakerInfo] = await PublicKey.findProgramAddress(
      [Buffer.from("staker_info"), stakingAccount.toBuffer(), walletPubkey.toBuffer()],
      program.programId,
    )

    // Try to fetch staker info
    let stakerInfoData
    try {
      stakerInfoData = await program.account.stakerInfo.fetch(stakerInfo)
    } catch (error) {
      // If staker info doesn't exist, return empty data
      return res.json({
        success: true,
        data: {
          wallet,
          totalStaked: "0",
          spinCount: 0,
          spinEligibilityTier: 0,
          stakeRecords: [],
        },
      })
    }

    // Get all stake records for this staker
    const stakeAccounts = await connection.getProgramAccounts(program.programId, {
      filters: [
        { dataSize: program.account.stakeRecord.size },
        { memcmp: { offset: 8, bytes: walletPubkey.toBase58() } }, // owner field
      ],
    })

    // Process stake records
    const stakeRecords = await Promise.all(
      stakeAccounts.map(async (account) => {
        const stakeRecord = await program.account.stakeRecord.fetch(account.pubkey)
        return {
          pubkey: account.pubkey.toString(),
          owner: stakeRecord.owner.toString(),
          amount: stakeRecord.amount.toString(),
          stakeTimestamp: stakeRecord.stakeTimestamp.toString(),
          endTimestamp: stakeRecord.endTimestamp.toString(),
          tier: stakeRecord.tier,
          spinCount: stakeRecord.spinCount,
          spinEligibilityTier: stakeRecord.spinEligibilityTier,
          isInitialized: stakeRecord.isInitialized,
        }
      }),
    )

    res.json({
      success: true,
      data: {
        wallet,
        totalStaked: stakerInfoData.totalStaked.toString(),
        spinCount: stakerInfoData.spinCount,
        spinEligibilityTier: stakerInfoData.spinEligibilityTier,
        stakedAmount: stakerInfoData.stakedAmount.toString(),
        stakeTimestamp: stakerInfoData.stakeTimestamp.toString(),
        stakeRecords,
      },
    })
  } catch (error) {
    console.error("Error getting user stakes:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

