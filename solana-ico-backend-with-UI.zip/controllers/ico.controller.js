const { Connection, PublicKey, Keypair } = require("@solana/web3.js")
const { Program, AnchorProvider, BN, web3 } = require("@project-serum/anchor")
const { TOKEN_PROGRAM_ID } = require("@solana/spl-token")
const icoIdl = require("../utils/idl/ico_program.json")
const { getKeypairFromEnv, createConnectionConfig } = require("../utils/solana")

// Initialize connection and program
const connection = createConnectionConfig()
const programId = new PublicKey(process.env.ICO_PROGRAM_ID)

// Get ICO details
exports.getIcoDetails = async (req, res) => {
  try {
    const provider = AnchorProvider.env()
    const program = new Program(icoIdl, programId, provider)

    const [icoAccount] = await PublicKey.findProgramAddress([Buffer.from("ico")], program.programId)

    const icoData = await program.account.icoAccount.fetch(icoAccount)

    res.json({
      success: true,
      data: {
        authority: icoData.authority.toString(),
        tokenMint: icoData.tokenMint.toString(),
        totalSupply: icoData.totalSupply.toString(),
        seedPrice: icoData.seedPrice.toString(),
        preIcoPrice: icoData.preIcoPrice.toString(),
        publicPrice: icoData.publicPrice.toString(),
        currentPublicPrice: icoData.currentPublicPrice.toString(),
        tokensSold: icoData.tokensSold.toString(),
        seedTokensSold: icoData.seedTokensSold.toString(),
        publicTokensSold: icoData.publicTokensSold.toString(),
        startTime: icoData.startTime.toString(),
        duration: icoData.duration.toString(),
        preIcoRoundDeadline: icoData.preIcoRoundDeadline.toString(),
        isActive: icoData.isActive,
        roundType: Object.keys(icoData.roundType)[0],
        seedInvestors: icoData.seedInvestors.map((investor) => investor.toString()),
        totalInvestors: icoData.totalInvestors.toString(),
        purchaseCounter: icoData.purchaseCounter.toString(),
        seedRoundAllocation: icoData.seedRoundAllocation.toString(),
        preIcoAllocation: icoData.preIcoAllocation.toString(),
        publicRoundAllocation: icoData.publicRoundAllocation.toString(),
      },
    })
  } catch (error) {
    console.error("Error fetching ICO details:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

// Initialize ICO
exports.initializeIco = async (req, res) => {
  try {
    const { totalSupply, seedPrice, preIcoPrice, publicPrice, startTime, duration, preIcoRoundDeadline } = req.body

    const provider = AnchorProvider.env()
    const program = new Program(icoIdl, programId, provider)

    // Get admin keypair from environment
    const adminKeypair = getKeypairFromEnv()

    // Find ICO account PDA
    const [icoAccount] = await PublicKey.findProgramAddress([Buffer.from("ico")], program.programId)

    // Get token mint from environment
    const tokenMint = new PublicKey(process.env.TOKEN_MINT_ADDRESS)

    // Convert parameters to BN
    const bnTotalSupply = new BN(totalSupply)
    const bnSeedPrice = new BN(seedPrice)
    const bnPreIcoPrice = new BN(preIcoPrice)
    const bnPublicPrice = new BN(publicPrice)
    const bnStartTime = new BN(startTime)
    const bnDuration = new BN(duration)
    const bnPreIcoRoundDeadline = new BN(preIcoRoundDeadline)

    // Initialize ICO
    const tx = await program.methods
      .initialize(
        bnTotalSupply,
        bnSeedPrice,
        bnPreIcoPrice,
        bnPublicPrice,
        bnStartTime,
        bnDuration,
        bnPreIcoRoundDeadline,
      )
      .accounts({
        authority: adminKeypair.publicKey,
        icoAccount,
        tokenMint,
        systemProgram: web3.SystemProgram.programId,
      })
      .signers([adminKeypair])
      .rpc()

    res.json({
      success: true,
      data: {
        transactionId: tx,
        icoAccount: icoAccount.toString(),
      },
    })
  } catch (error) {
    console.error("Error initializing ICO:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

// Buy tokens
exports.buyTokens = async (req, res) => {
  try {
    const { amount, buyerWallet } = req.body

    const provider = AnchorProvider.env()
    const program = new Program(icoIdl, programId, provider)

    // Find ICO account PDA
    const [icoAccount] = await PublicKey.findProgramAddress([Buffer.from("ico")], program.programId)

    // Fetch ICO data to get purchase counter
    const icoData = await program.account.icoAccount.fetch(icoAccount)

    // Create buyer public key
    const buyer = new PublicKey(buyerWallet)

    // Find purchase account PDA
    const [purchaseAccount] = await PublicKey.findProgramAddress(
      [Buffer.from("purchase"), buyer.toBuffer(), new BN(icoData.purchaseCounter).toArrayLike(Buffer, "le", 8)],
      program.programId,
    )

    // Get treasury wallet (authority from ICO account)
    const treasuryWallet = icoData.authority

    // Convert amount to lamports
    const amountLamports = new BN(amount)

    // Buy tokens
    const tx = await program.methods
      .buyTokens(amountLamports)
      .accounts({
        buyer,
        icoAccount,
        purchaseAccount,
        treasuryWallet,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: web3.SystemProgram.programId,
      })
      .rpc()

    res.json({
      success: true,
      data: {
        transactionId: tx,
        purchaseAccount: purchaseAccount.toString(),
      },
    })
  } catch (error) {
    console.error("Error buying tokens:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

// Distribute tokens
exports.distributeTokens = async (req, res) => {
  try {
    const { purchaseAccountAddress } = req.body

    const provider = AnchorProvider.env()
    const program = new Program(icoIdl, programId, provider)

    // Get admin keypair from environment
    const adminKeypair = getKeypairFromEnv()

    // Find ICO account PDA
    const [icoAccount] = await PublicKey.findProgramAddress([Buffer.from("ico")], program.programId)

    // Create purchase account public key
    const purchaseAccount = new PublicKey(purchaseAccountAddress)

    // Fetch purchase data
    const purchaseData = await program.account.purchaseAccount.fetch(purchaseAccount)

    // Get token mint from ICO account
    const icoData = await program.account.icoAccount.fetch(icoAccount)
    const tokenMint = icoData.tokenMint

    // Find treasury token account
    const treasuryTokenAccount = (
      await connection.getTokenAccountsByOwner(adminKeypair.publicKey, {
        mint: tokenMint,
      })
    ).value[0].pubkey

    // Find buyer token account
    const buyerTokenAccount = (
      await connection.getTokenAccountsByOwner(purchaseData.buyer, {
        mint: tokenMint,
      })
    ).value[0].pubkey

    // Distribute tokens
    const tx = await program.methods
      .distributeTokens()
      .accounts({
        authority: adminKeypair.publicKey,
        icoAccount,
        purchaseAccount,
        treasuryTokenAccount,
        buyerTokenAccount,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: web3.SystemProgram.programId,
      })
      .signers([adminKeypair])
      .rpc()

    res.json({
      success: true,
      data: {
        transactionId: tx,
      },
    })
  } catch (error) {
    console.error("Error distributing tokens:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

// Update round
exports.updateRound = async (req, res) => {
  try {
    const { newRound } = req.body

    const provider = AnchorProvider.env()
    const program = new Program(icoIdl, programId, provider)

    // Get admin keypair from environment
    const adminKeypair = getKeypairFromEnv()

    // Find ICO account PDA
    const [icoAccount] = await PublicKey.findProgramAddress([Buffer.from("ico")], program.programId)

    // Convert round type
    let roundType
    switch (newRound) {
      case "SeedRound":
        roundType = { seedRound: {} }
        break
      case "PreICO":
        roundType = { preIco: {} }
        break
      case "PublicICO":
        roundType = { publicIco: {} }
        break
      default:
        throw new Error("Invalid round type")
    }

    // Update round
    const tx = await program.methods
      .updateRound(roundType)
      .accounts({
        authority: adminKeypair.publicKey,
        icoAccount,
      })
      .signers([adminKeypair])
      .rpc()

    res.json({
      success: true,
      data: {
        transactionId: tx,
        newRound,
      },
    })
  } catch (error) {
    console.error("Error updating round:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

// End ICO
exports.endIco = async (req, res) => {
  try {
    const provider = AnchorProvider.env()
    const program = new Program(icoIdl, programId, provider)

    // Get admin keypair from environment
    const adminKeypair = getKeypairFromEnv()

    // Find ICO account PDA
    const [icoAccount] = await PublicKey.findProgramAddress([Buffer.from("ico")], program.programId)

    // End ICO
    const tx = await program.methods
      .endIco()
      .accounts({
        icoAccount,
      })
      .signers([adminKeypair])
      .rpc()

    res.json({
      success: true,
      data: {
        transactionId: tx,
      },
    })
  } catch (error) {
    console.error("Error ending ICO:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

// Get analytics
exports.getAnalytics = async (req, res) => {
  try {
    const provider = AnchorProvider.env()
    const program = new Program(icoIdl, programId, provider)

    // Find ICO account PDA
    const [icoAccount] = await PublicKey.findProgramAddress([Buffer.from("ico")], program.programId)

    // Fetch ICO data
    const icoData = await program.account.icoAccount.fetch(icoAccount)

    // Get all purchase accounts
    const purchaseAccounts = await connection.getProgramAccounts(program.programId, {
      filters: [
        { dataSize: program.account.purchaseAccount.size },
        { memcmp: { offset: 8 + 32, bytes: icoAccount.toBase58() } }, // ico field
      ],
    })

    // Process purchase data
    const purchases = await Promise.all(
      purchaseAccounts.map(async (account) => {
        const purchaseData = await program.account.purchaseAccount.fetch(account.pubkey)
        return {
          buyer: purchaseData.buyer.toString(),
          amount: purchaseData.amount.toString(),
          timestamp: purchaseData.timestamp.toString(),
          isDistributed: purchaseData.isDistributed,
          purchasePrice: purchaseData.purchasePrice.toString(),
          round: Object.keys(purchaseData.round)[0],
        }
      }),
    )

    // Calculate analytics
    const totalPurchases = purchases.length
    const totalDistributed = purchases.filter((p) => p.isDistributed).length
    const purchasesByRound = {
      SeedRound: purchases.filter((p) => p.round === "seedRound").length,
      PreICO: purchases.filter((p) => p.round === "preIco").length,
      PublicICO: purchases.filter((p) => p.round === "publicIco").length,
    }

    res.json({
      success: true,
      data: {
        totalSupply: icoData.totalSupply.toString(),
        tokensSold: icoData.tokensSold.toString(),
        seedTokensSold: icoData.seedTokensSold.toString(),
        publicTokensSold: icoData.publicTokensSold.toString(),
        totalInvestors: icoData.totalInvestors.toString(),
        currentRound: Object.keys(icoData.roundType)[0],
        isActive: icoData.isActive,
        totalPurchases,
        totalDistributed,
        purchasesByRound,
        purchases,
      },
    })
  } catch (error) {
    console.error("Error getting analytics:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

// Add seed investor
exports.addSeedInvestor = async (req, res) => {
  try {
    const { investorWallet } = req.body

    const provider = AnchorProvider.env()
    const program = new Program(icoIdl, programId, provider)

    // Get admin keypair from environment
    const adminKeypair = getKeypairFromEnv()

    // Find ICO account PDA
    const [icoAccount] = await PublicKey.findProgramAddress([Buffer.from("ico")], program.programId)

    // Create investor public key
    const investor = new PublicKey(investorWallet)

    // Add seed investor
    const tx = await program.methods
      .addSeedInvestor(investor)
      .accounts({
        authority: adminKeypair.publicKey,
        icoAccount,
      })
      .signers([adminKeypair])
      .rpc()

    res.json({
      success: true,
      data: {
        transactionId: tx,
        investor: investorWallet,
      },
    })
  } catch (error) {
    console.error("Error adding seed investor:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

// Remove seed investor
exports.removeSeedInvestor = async (req, res) => {
  try {
    const { investorWallet } = req.body

    const provider = AnchorProvider.env()
    const program = new Program(icoIdl, programId, provider)

    // Get admin keypair from environment
    const adminKeypair = getKeypairFromEnv()

    // Find ICO account PDA
    const [icoAccount] = await PublicKey.findProgramAddress([Buffer.from("ico")], program.programId)

    // Create investor public key
    const investor = new PublicKey(investorWallet)

    // Remove seed investor
    const tx = await program.methods
      .removeSeedInvestor(investor)
      .accounts({
        authority: adminKeypair.publicKey,
        icoAccount,
      })
      .signers([adminKeypair])
      .rpc()

    res.json({
      success: true,
      data: {
        transactionId: tx,
        investor: investorWallet,
      },
    })
  } catch (error) {
    console.error("Error removing seed investor:", error)
    res.status(500).json({
      success: false,
      error: error.message,
    })
  }
}

