import axios from "axios"

const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000/api"

const api = axios.create({
  baseURL: API_URL,
  headers: {
    "Content-Type": "application/json",
  },
})

// ICO API calls
export const getIcoDetails = async () => {
  const response = await api.get("/ico/details")
  return response.data
}

export const initializeIco = async (data) => {
  const response = await api.post("/ico/initialize", data)
  return response.data
}

export const buyTokens = async (data) => {
  const response = await api.post("/ico/buy-tokens", data)
  return response.data
}

export const distributeTokens = async (data) => {
  const response = await api.post("/ico/distribute-tokens", data)
  return response.data
}

export const updateRound = async (data) => {
  const response = await api.post("/ico/update-round", data)
  return response.data
}

export const endIco = async () => {
  const response = await api.post("/ico/end-ico")
  return response.data
}

export const getIcoAnalytics = async () => {
  const response = await api.get("/ico/analytics")
  return response.data
}

export const addSeedInvestor = async (data) => {
  const response = await api.post("/ico/add-seed-investor", data)
  return response.data
}

export const removeSeedInvestor = async (data) => {
  const response = await api.post("/ico/remove-seed-investor", data)
  return response.data
}

// Staking API calls
export const getStakingDetails = async () => {
  const response = await api.get("/staking/details")
  return response.data
}

export const initializeStaking = async (data) => {
  const response = await api.post("/staking/initialize", data)
  return response.data
}

export const stakeTokens = async (data) => {
  const response = await api.post("/staking/stake", data)
  return response.data
}

export const unstakeTokens = async (data) => {
  const response = await api.post("/staking/unstake", data)
  return response.data
}

export const updateStakingParams = async (data) => {
  const response = await api.post("/staking/update-params", data)
  return response.data
}

export const createCoupon = async (data) => {
  const response = await api.post("/staking/create-coupon", data)
  return response.data
}

// User API calls
export const getTokenBalance = async (wallet) => {
  const response = await api.get(`/users/token-balance/${wallet}`)
  return response.data
}

export const getUserPurchases = async (wallet) => {
  const response = await api.get(`/users/purchases/${wallet}`)
  return response.data
}

export const getUserStakes = async (wallet) => {
  const response = await api.get(`/users/stakes/${wallet}`)
  return response.data
}

export default api

